let liczba1 = prompt("Podaj pierwszą liczbę: ")
let liczba2 = prompt("Podaj drugą liczbę: ")
let suma = Number(liczba1) + Number(liczba2)
document.write("Suma liczby " + liczba1 + " i " + liczba2 + " wynosi " + suma + ".")