console.log(`AAAAAAAAAA`)

let a = 2
let b = 2

console.log(`a = ` + (++a))
console.log(`b = ` + (b))
console.log(`typ zmiennej a: ` + typeof(a))
console.log(`typ zmiennej b: ` + typeof(b))
document.write(a)
document.write(`<br>` + b)