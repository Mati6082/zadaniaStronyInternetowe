alert("Witaj na mojej stronie, dobrze Cię widzieć!")

let imie = prompt("Podaj swoje imię:"," anonim")
document.write("<h1 id='powitanie'>Cześć " + imie + "</h1>")
console.log("Cześć" + imie)